# NexusAI — Smart AI Cloud Platform

A production-ready, fully responsive landing page & dashboard UI for an AI Cloud Platform.

---

## 📁 Project Structure

```
smart-ai-cloud/
├── index.html          ← Main HTML page
├── css/
│   └── style.css       ← All styles (variables, layout, components, responsive)
├── js/
│   └── app.js          ← All interactivity (particles, counters, chart, modal, etc.)
└── README.md
```

---

## 🚀 Features

### UI Sections
| Section | Description |
|---|---|
| **Navbar** | Fixed, glass-blur nav with responsive hamburger menu |
| **Hero** | Animated headline, CTA buttons, animated stats counter bar |
| **Marquee** | Scrolling tech stack ticker |
| **Features** | 6-card feature grid (GPU, Models, Security, Observability, AutoML, Edge) |
| **Architecture** | Side-by-side explanation + animated platform diagram |
| **Dashboard Preview** | Functional live metrics dashboard with canvas chart |
| **Pricing** | 3-tier pricing with monthly/annual billing toggle |
| **Testimonials** | 3-column testimonial cards |
| **Contact** | Lead capture contact form |
| **Footer** | Full branded footer with links |

### Interactive JavaScript Features
- 🎇 **Floating particles** — CSS-animated background particles
- 🔢 **Number counters** — stats animate on scroll into view
- 📊 **Live dashboard metrics** — RPS and GPU counters tick in real-time
- 📈 **Canvas traffic chart** — smooth bezier line chart with 24h / 7d / 30d tabs
- 💰 **Billing toggle** — switches monthly ↔ annual pricing live
- 🪟 **Modal system** — sign-in / sign-up modals with keyboard close
- 🍞 **Toast notifications** — bottom-right feedback toasts
- 📜 **Scroll AOS** — animate-on-scroll for all cards
- 🔵 **Navbar shrink** — compact on scroll
- 📱 **Hamburger menu** — mobile-responsive nav

---

## 🎨 Design System

```
Colors:
  --accent  : #00d4ff  (cyan — primary CTA)
  --accent2 : #7c3aed  (purple — secondary)
  --accent3 : #06ffa5  (green — success/status)
  --amber   : #f59e0b  (warnings / ratings)
  --primary : #0a0f1e  (dark base background)

Fonts:
  Display : Syne (headings, logo, numbers)
  Body    : DM Sans (all body text, UI)
```

---

## 🖥️ How to Run

Simply open `index.html` in any modern browser:

```bash
# Option 1 — direct open
open index.html

# Option 2 — local server (recommended for fonts)
npx serve .
# or
python3 -m http.server 8080
```

No build tools, no dependencies, no npm install required.

---

## 📱 Responsive Breakpoints

| Breakpoint | Layout |
|---|---|
| `> 1024px` | Full 3-column layout |
| `768–1024px` | 2-column features, stacked architecture |
| `< 768px` | Single column, hamburger nav, stacked dashboard |
| `< 480px` | Mobile-optimized spacing and typography |

---

## 🔧 Customization

**Change brand name:** Search/replace `NexusAI` in `index.html`

**Change colors:** Edit `:root` variables in `css/style.css`

**Add a page section:** Copy an existing `<section>` block in `index.html`, add styles in `style.css`

**Change pricing:** Update `data-monthly` and `data-annual` attributes on `.price-val` spans
